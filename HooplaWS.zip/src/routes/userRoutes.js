const express = require("express");
const userRouting = express.Router();
const userService = require('../service/user');
const UserRegister = require('../model/userRegister')
const {checkEmailId} = require('../model/user')

//Setup the database
userRouting.get("/userDBsetup", (req, res, next) => {
    userService.setupDB().then( response =>{
        if(response) res.json({ message : "Successfully inserted "+ response +" documents into database"})
    }).catch( error =>{
       next(error);
    })
})

//User LOGIN
userRouting.post('/login', (req,res,next)=>{
    var uEmail= req.body.uEmail;
    var uPass=req.body.uPass;
    return userService.loginUser(uEmail, uPass).then(userData => {
        res.json(userData);
    }).catch(err => {
        console.log(err.message)
        next(err);
    });
});
//User REGISTER
userRouting.post('/register',checkEmailId,(req,res,next)=>{
    const userDetails = new UserRegister(req.body);
    return userService.registerUser(userDetails)
    .then(userData => {
        res.json(userData);
    })
    .catch(err => {
        console.log(err.message)
        next(err);
    });
});

module.exports = userRouting