class UserRegister {
    constructor(obj) {
        this.uCredentials = {
            uEmail:obj.uEmail,
            uPass:obj.uPass
        };
        this.uProfile={
            uName : obj.uName,
            uDOB :obj.uDOB,
            uPhone :obj.uPhone,
            uDateJoined :new Date().toISOString() 
        }
    }
}

module.exports = UserRegister;

