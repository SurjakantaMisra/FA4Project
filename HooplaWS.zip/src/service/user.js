const dbLayer = require('../model/user');

user = {}

user.setupDB = () => {
   return dbLayer.setupDB().then( response => {  
    if(response){
        return response;
       }else{
           let err = new Error('Insertion Failed');
           err.status = 500;
          throw err;
       } 
   });
}
//Verfying the credentials of user
user.loginUser = (uEmail,pass) => {
    return dbLayer.userLogin(uEmail,pass).then( response => {
        return response
    })
}
user.registerUser = (userDetails) => {
    return dbLayer.registerUser(userDetails).then( response => {
        return response
    })
}

module.exports = user