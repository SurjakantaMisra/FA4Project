import React, { Component, Fragment } from 'react';
import { BrowserRouter as Router, Route, Switch,Link } from 'react-router-dom';
import './App.css';
import Login from "./Login";
import Register from "./Register";
import CategoryTabComponent from './Category'
import ViewProducts from './ViewProducts'
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
// import './searchBar.css'
import SearchIcon from '@material-ui/icons/Search';
import ViewProductDetails from './ViewProductDetails'

class App extends Component {
  constructor() {
    super()
    this.state = {
      form:
      {
        search: ''
      },
      viewProducts:false,
      
    }
  }
  handleChange = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    let form = this.state.form;
    form[name] = value
    this.setState({ form: form })
  }
  handleSubmit = (event) => {
    event.preventDefault()
    this.setState({viewProducts:true})
  }
  logout=()=>
  {
    sessionStorage.clear();
    window.location.reload();
  }
  render() {
    return (
      <div>
        <Router>
          <Fragment>
            <div style={{ marginBottom: '4.7%' }}>
              {/* <Navbar/> */}
              <React.Fragment >
                <AppBar>
                  <Toolbar>
                    <Typography variant="h6" noWrap >
                      <Link className='text-white' to='/dashboard' exact={"true"}>Hoopla</Link>
                    </Typography>&nbsp;&nbsp;
                      <form onSubmit={this.handleSubmit}>
                      <div className="searchbar ">
                        <input
                          className="search_input"
                          type="text"
                          onChange={this.handleChange}
                          name="search"
                          value={this.state.form.search}
                          placeholder="  Search..." />
                        <Link to="/viewProducts"exact={"true"}><button className='search_icon  '><SearchIcon/></button></Link>

                      </div>
                    </form>
                    
                    {
                      sessionStorage.getItem('uEmail') === null ?
                      <div className='ml-auto'>
                        <Link className=" ml-auto text-white" to="/register" >Register</Link>&nbsp;&nbsp;
                        <Link className="  ml-auto text-white" to="/login" >Login</Link>
                        </div>
                        :
                        <div className='ml-auto'>
                            <span className='text-capitalize font-weight-bold font-italic'>Welcome&nbsp;{sessionStorage.getItem('uName')}&nbsp;&nbsp;</span>
                          <button type='button'onClick={this.logout} className='btn btn-warning ml-auto'>Logout</button>
                        </div>
                    }
                  </Toolbar>
                </AppBar>
              </React.Fragment>

            </div>
            <Switch>
              <Route exact path='/dashboard' component={CategoryTabComponent} />
              <Route exact path='/login' component={() => <Login />} />
              <Route exact path='/register' component={() => <Register />} />
              <Route exact path='/viewProducts' component={() => <ViewProducts search={this.state.form.search} />} />
              <Route exact path='/viewProductDetails/:_id' component={({ match }) => <ViewProductDetails match={match} />} />
              <Route exact path='/' component={CategoryTabComponent} />              
            </Switch>
          </Fragment>
        </Router>
      </div>
    );
  }
}

export default App