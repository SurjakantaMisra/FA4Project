
import React, { Component } from 'react'
import axios from 'axios'
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import CircularProgress from '@material-ui/core/CircularProgress';
import { Link } from 'react-router-dom';

const backendUrl = 'http://localhost:2000/product/getProducts/'

const useStyles = makeStyles((theme) => ({
    root: {
        maxWidth: 245,
        flexGrow: 1,
        display: 'flex',
        '& > * + *': {
            marginLeft: theme.spacing(2),
        },
    },
}));

export class ProductList extends Component {

    constructor(props) {
        super(props)

        this.state = {
            productsArray: [],
            errorMessage: "",
        }
    }

    componentDidMount() {
        if (this.props.category !== undefined) {
            axios.get(`${backendUrl}${this.props.category}`).then(response => {
                this.setState({ productsArray: response.data })
            }).catch(error => {
                if (error.response) {
                    this.setState({ errorMessage: error.response.data.message })
                } else {
                    this.setState({ errorMessage: error.message })
                }
            })

        }
        else if (this.props.search !== undefined) {
            axios.get(`http://localhost:2000/product/search/${this.props.search}`).then(response => {
                this.setState({ productsArray: response.data })
            }).catch(error => {
                if (error.response) {
                    this.setState({ errorMessage: error.response.data.message })
                } else {
                    this.setState({ errorMessage: error.message })
                }
            })

        }
    }

    render() {
        const { classes } = this.props;
        return (
            <div className="mt-5" style={{ marginLeft: '2%' }}>
                <Grid container spacing={2}>
                    {
                        this.state.productsArray ? this.state.productsArray.map((product, index) => {
                            return (

                                <Grid item xs={6} sm={3} md={3} lg={3} key={index} >
                                    <Card className={classes.root} style={{
                                        display: 'block',
                                        width: '250px',
                                        height: "350px"
                                    }}>
                                        <Link to={`/viewProductDetails/${product._id}`}  >
                                            <CardActionArea >
                                                <img src={require(`../assets/img/${product.image}`)} alt={product.pName} style={{ width: "250px", height: '250px' }} />
                                                <CardContent>
                                                    <p className='badge badge-danger float-right'>{product.pRating}</p>
                                                    <p className='text-left'>{product.pName}</p>
                                                    <p className='text-right font-weight-bold '>₹ {product.price}</p>

                                                </CardContent>
                                            </CardActionArea>
                                        </Link>
                                    </Card>
                                </Grid>
                            )


                        }) : <CircularProgress />
                    }


                </Grid>
            </div>
        )
    }
}

export default withStyles(useStyles)(ProductList);
