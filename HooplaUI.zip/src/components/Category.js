import React, { Component } from 'react';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import withStyles from '@material-ui/core/styles/withStyles';
import ViewProducts from './ViewProducts'
import axios from "axios";
import Slider from 'react-animated-slider';
import 'react-animated-slider/build/horizontal.css';

const slides = [
    <img src={require("../assets/img/clothing.png")} className="img-fluid " alt="Clothing Pic" />,
    <img src={require("../assets/img/furnitures.png")} className="img-fluid" alt="Furniture Pic" />,
    <img src={require("../assets/img/shoes.png")} className="img-fluid" alt="Shoes Pic" />,
    <img src={require("../assets/img/mobiles.png")} className="img-fluid" alt="Mobiles Pic" />
];


const backendUrl = 'http://localhost:2000/product/getAllProductCategories'
const styles = theme => ({
    root: {
        flexGrow: 1,
        width: '100%',
        backgroundColor: theme.palette.background.paper,
        outline:"none"
      },   
})
class Category extends Component {
    constructor(props) {
        super(props)
        this.state = {
            value: -1,
            errorMessage: '',
            categories: [],
        }
    }
    handleChange = (event, newValue) => {
        this.setState({ value: newValue })
    };
    componentDidMount() {
        axios.get(backendUrl)
            .then(response => {
                this.setState({ categories: response.data, errorMessage: null })
            })
            .catch(error => {
                this.setState({ errorMessage: error.response ? error.response.data.message : error.message, categories: null })
            })
    }
    render() {
        const { classes } = this.props;

        return (
            <div className={classes.root}>
                <AppBar position='static'>
                    <Tabs
                        value={this.state.value}
                        onChange={this.handleChange}
                        centered
                        textColor="white"
                        variant="fullWidth"
                    >
                        {
                            this.state.categories.map(category => <Tab label={category} />)
                        }
                    </Tabs>
                </AppBar>
                {this.state.value === -1 && <Slider>{slides.map((slide, index) => slide)}</Slider>}
                {this.state.value === 0 && <ViewProducts category={this.state.categories[this.state.value]} />}
                {this.state.value === 1 && <ViewProducts category={this.state.categories[this.state.value]} />}
                {this.state.value === 2 && <ViewProducts category={this.state.categories[this.state.value]} />}
                {this.state.value === 3 && <ViewProducts category={this.state.categories[this.state.value]} />}


            </div>
        );
    }
}


export default withStyles(styles)(Category)