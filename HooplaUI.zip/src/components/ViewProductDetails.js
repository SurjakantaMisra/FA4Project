import React from 'react'
import axios from 'axios'
import CircularProgress from '@material-ui/core/CircularProgress';
import { Redirect } from 'react-router-dom';



class ViewProductDetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            productDetails: '',
            errorMessage:''
        }
    }
    componentDidMount() {
        const { match: { params } } = this.props;
        console.log(params._id)
      
        axios.get(`http://localhost:2000/product/productDetails/${params._id}`)
        .then(response => {
            console.log(response.data[0])
            this.setState({ productDetails: response.data[0],errorMessage: null })
        }).catch(error => {
            if (error.response) {
                this.setState({ errorMessage: error.response.data.message })
            } else {
                this.setState({ errorMessage: error.message,productDetails:null })
            }
        })
      }
    render() {
        return (
            sessionStorage.getItem('uEmail') === null?
            <Redirect to='/login'></Redirect>:
            this.state.productDetails?
            <div className="container">
                <div className="row  ">
                    <div className="col mt-5">
                    <img src={require(`../assets/img/${this.state.productDetails.image}`)} alt={this.state.productDetails.pName} style={{ width: "400px", height: '400px' }} />
                    </div>
                    <div className="col mt-5">
                            <h6 className='font-weight-bold '>{this.state.productDetails.pCategory}</h6>
                            <p>{this.state.productDetails.pName}</p>
                            <p><span className='font-weight-bold '>Seller&nbsp;</span>{this.state.productDetails.pSeller.s_Id}</p>
                            <h6 className='font-weight-bold '>Description</h6>
                            <p className='text-capitalize'>{this.state.productDetails.pDescription}</p>
                            <h6 className='font-weight-bold '>Specifications</h6>
                            <ul>
                                <li><span className='font-weight-bold '>Color&nbsp;</span>{this.state.productDetails.color} </li>
                            </ul>
                            <h6 className='font-weight-bold '>Rating&nbsp;<p className='badge badge-danger'>{this.state.productDetails.pRating}</p></h6>
                            <h6 className='font-weight-bold '>Price</h6>
                            <p className=' font-weight-bold '>₹{Number(this.state.productDetails.price)-(Number(this.state.productDetails.pSeller.pDiscount)*Number(this.state.productDetails.price))}</p>
                            <p ><del>₹ {this.state.productDetails.price}</del></p>
                            <h6 className=' text-warning '>{Number(this.state.productDetails.pSeller.pDiscount)*100}%Off&nbsp; + &nbsp;{this.state.productDetails.pSeller.pShippingCharges}&nbsp;shipping charges</h6>
                            <h6 className='font-weight-bold '>Availability</h6>
                            <p>{this.state.productDetails.pSeller.pQuantity}</p>

                            <button type='button' className='btn btn-primary'>Add To Cart</button>
                            <button type='button' className='btn btn-warning ml-2'>Go Back</button>

                    </div>
                </div>
            </div>:<CircularProgress/>
            )
    }
}
export default ViewProductDetails;